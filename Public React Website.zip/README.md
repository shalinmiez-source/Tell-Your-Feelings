
  # Public React Website

  This is a code bundle for Public React Website. The original project is available at https://www.figma.com/design/LMR1sRNOAlK2PhzyWox4si/Public-React-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  