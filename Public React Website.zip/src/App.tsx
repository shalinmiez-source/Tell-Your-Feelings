import React, { useState } from 'react';
import { NewsSlide } from './components/NewsSlide';
import { TimelineSlide } from './components/TimelineSlide';
import { MenfessSlide } from './components/MenfessSlide';

export default function App() {
  const [activeTab, setActiveTab] = useState<'news' | 'timeline' | 'menfess'>('menfess');

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#d4f1dd] via-[#f5e6f0] to-[#ffd9e5]">
      {/* Header */}
      <div className="bg-white/60 backdrop-blur-sm border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4">
          {/* Tab Navigation */}
          <div className="flex justify-center gap-2 mb-4">
            <button
              onClick={() => setActiveTab('news')}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeTab === 'news'
                  ? 'bg-gradient-to-r from-[#ff9eb3] to-[#c77dff] text-white shadow-md'
                  : 'bg-white/70 text-gray-600 hover:bg-white'
              }`}
            >
              News
            </button>
            <button
              onClick={() => setActiveTab('timeline')}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeTab === 'timeline'
                  ? 'bg-gradient-to-r from-[#7dd87d] to-[#4ecdc4] text-white shadow-md'
                  : 'bg-white/70 text-gray-600 hover:bg-white'
              }`}
            >
              Timeline
            </button>
            <button
              onClick={() => setActiveTab('menfess')}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeTab === 'menfess'
                  ? 'bg-gradient-to-r from-[#ff9eb3] to-[#c77dff] text-white shadow-md'
                  : 'bg-white/70 text-gray-600 hover:bg-white'
              }`}
            >
              Menfess
            </button>
          </div>

          {/* Title */}
          <div className="text-center">
            <h1 className="text-gray-800 mb-1">Tell Your Feelings</h1>
            <p className="text-sm text-gray-500">
              Share your feelings through news, images, and anonymous messages
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {activeTab === 'news' && <NewsSlide />}
        {activeTab === 'timeline' && <TimelineSlide />}
        {activeTab === 'menfess' && <MenfessSlide />}
      </div>

      {/* Footer */}
      <div className="fixed bottom-4 right-4 z-50">
        <a 
          href="https://www.instagram.com/rilism18?igsh=MTlvZmxuMjZ4cnZrcw==" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-md text-xs text-gray-600 flex items-center gap-2 hover:bg-white hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer border border-white/50"
        >
          <span className="animate-pulse">✨</span> by rilism
        </a>
      </div>
    </div>
  );
}
