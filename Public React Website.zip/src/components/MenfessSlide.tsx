import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, X } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface MenfessMessage {
  id: string;
  from: string;
  to: string;
  message: string;
  songLink: string;
  photos: string[];
  color: string;
  timestamp: number;
}

const colorThemes = {
  blue: { 
    bg: 'bg-gradient-to-br from-blue-100/90 to-blue-50/80', 
    border: 'border-blue-200', 
    emoji: '💙',
    avatar: '#a7c7e7',
    glow: 'rgba(167, 199, 231, 0.6)'
  },
  purple: { 
    bg: 'bg-gradient-to-br from-purple-100/90 to-purple-50/80', 
    border: 'border-purple-200', 
    emoji: '💜',
    avatar: '#c8b6ff',
    glow: 'rgba(200, 182, 255, 0.6)'
  },
  yellow: { 
    bg: 'bg-gradient-to-br from-yellow-100/90 to-yellow-50/80', 
    border: 'border-yellow-200', 
    emoji: '💛',
    avatar: '#ffd97d',
    glow: 'rgba(255, 217, 125, 0.6)'
  },
  pink: { 
    bg: 'bg-gradient-to-br from-pink-100/90 to-pink-50/80', 
    border: 'border-pink-200', 
    emoji: '💗',
    avatar: '#ffc6d3',
    glow: 'rgba(255, 198, 211, 0.6)'
  },
  green: { 
    bg: 'bg-gradient-to-br from-green-100/90 to-green-50/80', 
    border: 'border-green-200', 
    emoji: '💚',
    avatar: '#b2e4c4',
    glow: 'rgba(178, 228, 196, 0.6)'
  }
};

export function MenfessSlide() {
  const [messages, setMessages] = useState<MenfessMessage[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState<{ id: string; step: number } | null>(null);
  const [newMessage, setNewMessage] = useState({
    from: '',
    to: '',
    message: '',
    songLink: '',
    color: 'pink' as keyof typeof colorThemes,
  });
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/menfess`,
        {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        // Server already returns messages sorted newest first
        setMessages(Array.isArray(data) ? data : []);
      } else {
        console.error('Error fetching menfess messages - HTTP status:', response.status);
      }
    } catch (err) {
      // Continue silently - the server might not be ready yet or there's a network issue
      // This is expected on first load before the server is fully initialized
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files).slice(0, 4);
      setSelectedFiles(files);
    }
  };

  const handleSubmit = async () => {
    try {
      const formData = new FormData();
      formData.append('from', newMessage.from);
      formData.append('to', newMessage.to);
      formData.append('message', newMessage.message);
      formData.append('songLink', newMessage.songLink);
      formData.append('color', newMessage.color);
      
      selectedFiles.forEach((file, index) => {
        formData.append(`photo${index}`, file);
      });

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/menfess`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: formData,
        }
      );

      if (response.ok) {
        const newMsg = await response.json();
        // Add new message to the beginning of the list immediately
        setMessages(prev => [newMsg, ...prev]);
        setNewMessage({ from: '', to: '', message: '', songLink: '', color: 'pink' });
        setSelectedFiles([]);
        setError('');
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to post');
      }
    } catch (err) {
      setError('Network error');
      console.error('Error creating message:', err);
    }
  };

  const handleDeleteClick = (msgId: string) => {
    if (!deleteConfirmation) {
      setDeleteConfirmation({ id: msgId, step: 1 });
    } else if (deleteConfirmation.id === msgId && deleteConfirmation.step === 1) {
      setDeleteConfirmation({ id: msgId, step: 2 });
    } else if (deleteConfirmation.id === msgId && deleteConfirmation.step === 2) {
      handleDelete(msgId);
    }
  };

  const handleDelete = async (msgId: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/menfess/${msgId}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        }
      );

      if (response.ok) {
        setDeleteConfirmation(null);
        setError('');
        // Remove message from list immediately
        setMessages(prev => prev.filter(m => m.id !== msgId));
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to delete');
      }
    } catch (err) {
      setError('Network error');
      console.error('Error deleting message:', err);
    }
  };

  const getSongEmbedUrl = (url: string) => {
    if (url.includes('spotify.com')) {
      const trackId = url.match(/track\/([a-zA-Z0-9]+)/)?.[1];
      return trackId ? `https://open.spotify.com/embed/track/${trackId}?utm_source=generator&theme=0` : null;
    }
    return null;
  };

  const filteredMessages = messages.filter((msg) =>
    searchQuery.trim() === '' ||
    msg.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
    msg.to.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Helper function to get initials from name
  const getInitials = (name: string) => {
    if (!name) return '?';
    const words = name.trim().split(' ');
    if (words.length === 1) return words[0].charAt(0).toUpperCase();
    return (words[0].charAt(0) + words[words.length - 1].charAt(0)).toUpperCase();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-[#d946a6] mb-2">💌 Menfess</h2>
        <p className="text-sm text-gray-600">Share anonymous messages with optional Spotify tracks</p>
      </div>

      {/* Send Message Form */}
      <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg p-6 mb-6 border border-white/50">
        <h3 className="text-[#d946a6] text-center mb-6">Send Anonymous Message</h3>
        
        <div className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={newMessage.from}
              onChange={(e) => setNewMessage({ ...newMessage, from: e.target.value })}
              placeholder="From (your name)"
              maxLength={50}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#d946a6] focus:ring-2 focus:ring-[#d946a6]/20 transition-all duration-300"
            />
            <span className="absolute right-4 top-3 text-xs text-gray-400">{newMessage.from.length}/50</span>
          </div>

          <div className="relative">
            <input
              type="text"
              value={newMessage.to}
              onChange={(e) => setNewMessage({ ...newMessage, to: e.target.value })}
              placeholder="To (recipient name)"
              maxLength={50}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#d946a6] focus:ring-2 focus:ring-[#d946a6]/20 transition-all duration-300"
            />
            <span className="absolute right-4 top-3 text-xs text-gray-400">{newMessage.to.length}/50</span>
          </div>

          <div className="relative">
            <textarea
              value={newMessage.message}
              onChange={(e) => setNewMessage({ ...newMessage, message: e.target.value })}
              placeholder="Your message..."
              maxLength={500}
              rows={4}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#d946a6] focus:ring-2 focus:ring-[#d946a6]/20 transition-all duration-300 resize-none"
            />
            <span className="absolute right-4 bottom-3 text-xs text-gray-400">{newMessage.message.length}/500</span>
          </div>

          {/* Color Selection */}
          <div>
            <label className="block text-sm text-gray-600 mb-3 text-center">Choose card color:</label>
            <div className="flex gap-3 justify-center">
              {Object.entries(colorThemes).map(([key, theme]) => (
                <button
                  key={key}
                  onClick={() => setNewMessage({ ...newMessage, color: key as keyof typeof colorThemes })}
                  className={`w-12 h-12 rounded-full transition-all duration-300 flex items-center justify-center text-xl ${
                    newMessage.color === key
                      ? 'ring-4 ring-[#d946a6] ring-offset-2 scale-110 shadow-lg'
                      : 'hover:scale-105 shadow-md hover:shadow-lg'
                  } ${theme.bg} border-2 ${theme.border}`}
                  style={{
                    boxShadow: newMessage.color === key 
                      ? `0 4px 20px ${theme.glow}, 0 0 0 4px #d946a6` 
                      : `0 2px 8px ${theme.glow}`
                  }}
                >
                  {theme.emoji}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <input
              type="text"
              value={newMessage.songLink}
              onChange={(e) => setNewMessage({ ...newMessage, songLink: e.target.value })}
              placeholder="Spotify link (optional)"
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#d946a6] focus:ring-2 focus:ring-[#d946a6]/20 transition-all duration-300"
            />
            <p className="mt-1 text-xs text-[#d946a6]/70 italic">Pair a song with your message</p>
          </div>

          <div>
            <label className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 hover:border-[#d946a6] hover:bg-[#d946a6]/5 transition-all duration-300 cursor-pointer shadow-sm hover:shadow-md">
              <Upload className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">
                {selectedFiles.length > 0 ? `${selectedFiles.length} photo(s) selected ✓` : 'Upload photos (optional, max 4)'}
              </span>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          </div>

          {error && <p className="text-red-500 text-sm text-center">{error}</p>}

          <button
            onClick={handleSubmit}
            disabled={!newMessage.to || !newMessage.message}
            className="w-full py-3 rounded-full bg-gradient-to-r from-[#ff9eb3] to-[#c77dff] text-white hover:shadow-lg hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
          >
            <span>✉️</span> <span>Send Message</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="🔍 Search messages by user name..."
          className="w-full px-5 py-3 rounded-full bg-white/80 backdrop-blur-sm border-2 border-gray-200 focus:outline-none focus:border-[#d946a6] focus:ring-2 focus:ring-[#d946a6]/20 transition-all duration-300 shadow-sm hover:shadow-md"
        />
      </div>

      {/* Messages Feed */}
      <div className="relative">
        <h3 className="text-sm text-gray-600 mb-4">Message Feed ({filteredMessages.length})</h3>
        {filteredMessages.length === 0 ? (
          <div className="text-center py-16 bg-white/60 backdrop-blur-sm rounded-3xl shadow-md border border-white/50">
            <div className="text-6xl mb-4">💌</div>
            <p className="text-gray-500">No messages yet. Be the first to send one!</p>
          </div>
        ) : (
          <div className="max-h-[800px] overflow-y-auto space-y-4 pr-2 custom-scrollbar">
            <AnimatePresence mode="popLayout">
              {filteredMessages.map((msg, index) => {
                const theme = colorThemes[msg.color as keyof typeof colorThemes] || colorThemes.pink;
                const isDeleting = deleteConfirmation?.id === msg.id;
                
                return (
                  <motion.div
                    key={msg.id}
                    layout
                    initial={{ opacity: 0, y: -30, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 30, scale: 0.95 }}
                    transition={{ 
                      duration: 0.5,
                      delay: index * 0.05,
                      ease: [0.25, 0.1, 0.25, 1]
                    }}
                    className={`${theme.bg} backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-xl p-6 relative group border-2 ${theme.border} transition-all duration-300`}
                  >
                    {/* Delete Button */}
                    {isDeleting ? (
                      <div className="absolute top-3 right-3 flex flex-col gap-2 z-10 bg-white/90 p-3 rounded-2xl shadow-lg">
                        <p className="text-xs text-gray-700 mb-1">
                          {deleteConfirmation.step === 1 
                            ? 'Are you sure you want to delete this message?' 
                            : 'Really delete it?'}
                        </p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleDeleteClick(msg.id)}
                            className="px-3 py-1 bg-red-500 text-white rounded-full hover:bg-red-600 text-xs"
                          >
                            Yes
                          </button>
                          <button
                            onClick={() => setDeleteConfirmation(null)}
                            className="px-3 py-1 bg-gray-500 text-white rounded-full hover:bg-gray-600 text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleDeleteClick(msg.id)}
                        className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity bg-red-400/80 hover:bg-red-500/80 text-white p-2 rounded-full"
                        title="Delete message"
                      >
                        🗑️
                      </button>
                    )}

                    {/* Header with avatars and names */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3 flex-1">
                        {/* From Avatar */}
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white transition-all duration-300 hover:scale-110 cursor-pointer relative group/avatar"
                            style={{ 
                              backgroundColor: theme.avatar,
                              boxShadow: `0 0 0 2px white, 0 0 12px ${theme.glow}`
                            }}
                          >
                            <span className="text-sm select-none">{getInitials(msg.from || 'Anonymous')}</span>
                            <div 
                              className="absolute inset-0 rounded-full opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-300"
                              style={{ 
                                boxShadow: `0 0 20px ${theme.glow}, 0 0 30px ${theme.glow}`
                              }}
                            />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs text-gray-500">From:</span>
                            <span className="text-sm text-gray-800">{msg.from || 'Anonymous'}</span>
                          </div>
                        </div>

                        {/* Arrow */}
                        <span className="text-gray-400 mx-1">→</span>

                        {/* To Avatar */}
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white transition-all duration-300 hover:scale-110 cursor-pointer relative group/avatar"
                            style={{ 
                              backgroundColor: theme.avatar,
                              boxShadow: `0 0 0 2px white, 0 0 12px ${theme.glow}`
                            }}
                          >
                            <span className="text-sm select-none">{getInitials(msg.to)}</span>
                            <div 
                              className="absolute inset-0 rounded-full opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-300"
                              style={{ 
                                boxShadow: `0 0 20px ${theme.glow}, 0 0 30px ${theme.glow}`
                              }}
                            />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs text-gray-500">To:</span>
                            <span className="text-sm text-gray-800">{msg.to}</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Timestamp */}
                      <div className="text-xs text-gray-400 ml-2">
                        {new Date(msg.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>

                    {/* Message */}
                    <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-3 shadow-sm">
                      <p className="text-sm text-gray-700 leading-relaxed">{msg.message}</p>
                    </div>

                    {/* Spotify Embed */}
                    {msg.songLink && getSongEmbedUrl(msg.songLink) && (
                      <div className="mb-3 rounded-2xl overflow-hidden bg-black shadow-md">
                        <iframe
                          src={getSongEmbedUrl(msg.songLink)!}
                          width="100%"
                          height="152"
                          frameBorder="0"
                          allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                          loading="lazy"
                        />
                      </div>
                    )}

                    {/* Photos */}
                    {msg.photos && msg.photos.length > 0 && (
                      <div className={`grid ${msg.photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2'} gap-3`}>
                        {msg.photos.map((photo, idx) => (
                          <img
                            key={idx}
                            src={photo}
                            alt={`Photo ${idx + 1}`}
                            className={`w-full ${msg.photos.length === 1 ? 'h-48' : 'h-32'} object-cover rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300`}
                          />
                        ))}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
