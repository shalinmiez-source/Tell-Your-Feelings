import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Youtube, Instagram, X } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface NewsPost {
  id: string;
  url: string;
  type: 'youtube' | 'instagram';
  timestamp: number;
}

export function NewsSlide() {
  const [posts, setPosts] = useState<NewsPost[]>([]);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeletePassword, setShowDeletePassword] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [newPost, setNewPost] = useState({ url: '', type: 'youtube' as 'youtube' | 'instagram' });
  const [error, setError] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if password is stored in session
    const storedPassword = sessionStorage.getItem('rilism_password');
    if (storedPassword === 'RILISMWEIGHTEEN2526') {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
    const interval = setInterval(fetchPosts, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/news`,
        {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        setPosts(Array.isArray(data) ? data : []);
      } else {
        console.error('Error fetching news posts - HTTP status:', response.status);
      }
    } catch (err) {
      // Continue silently - the server might not be ready yet or there's a network issue
      // This is expected on first load before the server is fully initialized
    }
  };

  const handleSubmit = async () => {
    try {
      const postPassword = isAuthenticated ? sessionStorage.getItem('rilism_password') : password;
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/news`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ password: postPassword, ...newPost }),
        }
      );

      if (response.ok) {
        const newPostData = await response.json();
        // Store password in session on successful post
        if (!isAuthenticated) {
          sessionStorage.setItem('rilism_password', password);
          setIsAuthenticated(true);
        }
        // Add new post immediately to the list
        setPosts(prev => [newPostData, ...prev]);
        setShowPasswordModal(false);
        setPassword('');
        setNewPost({ url: '', type: 'youtube' });
        setError('');
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to post');
      }
    } catch (err) {
      setError('Network error');
      console.error('Error creating post:', err);
    }
  };

  const handleDeleteClick = (postId: string) => {
    // First confirmation
    setShowDeleteConfirm(postId);
    setDeleteError('');
  };

  const handleDeleteConfirm = (postId: string) => {
    // Second confirmation - show password input
    setShowDeleteConfirm(null);
    setShowDeletePassword(postId);
  };

  const handleDelete = async (postId: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/news/${postId}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ password: deletePassword }),
        }
      );

      if (response.ok) {
        // Remove post immediately from the list
        setPosts(prev => prev.filter(p => p.id !== postId));
        setShowDeletePassword(null);
        setDeletePassword('');
        setDeleteError('');
      } else {
        const data = await response.json();
        setDeleteError(data.error || 'Failed to delete');
      }
    } catch (err) {
      setDeleteError('Network error');
      console.error('Error deleting post:', err);
    }
  };

  const getEmbedUrl = (url: string, type: string) => {
    if (type === 'youtube') {
      const videoId = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/)?.[1];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-[#ff6b6b] mb-2">📰 News</h2>
        <p className="text-sm text-gray-600">Share YouTube or Instagram snippets with the community</p>
      </div>

      {/* Post Form */}
      <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg p-6 mb-6 border border-white/50">
        <div className="flex justify-center mb-6">
          <h3 className="text-gray-800">Post to News</h3>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-700 mb-2">Select Platform</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setNewPost({ ...newPost, type: 'youtube' })}
                className={`py-4 px-4 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center gap-2 shadow-sm hover:shadow-md ${
                  newPost.type === 'youtube'
                    ? 'border-[#ff6b6b] bg-[#ff6b6b]/10 scale-105'
                    : 'border-gray-200 hover:border-gray-300 hover:scale-102'
                }`}
              >
                <Youtube className="w-6 h-6 text-red-500 transition-transform group-hover:scale-110" />
                <p className="text-sm text-gray-700">YouTube</p>
              </button>
              <button
                onClick={() => setNewPost({ ...newPost, type: 'instagram' })}
                className={`py-4 px-4 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center gap-2 shadow-sm hover:shadow-md ${
                  newPost.type === 'instagram'
                    ? 'border-[#ff6b6b] bg-[#ff6b6b]/10 scale-105'
                    : 'border-gray-200 hover:border-gray-300 hover:scale-102'
                }`}
              >
                <Instagram className="w-6 h-6 text-pink-500 transition-transform group-hover:scale-110" />
                <p className="text-sm text-gray-700">Instagram</p>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-700 mb-2">
              {newPost.type === 'youtube' ? 'YouTube' : 'Instagram'} URL
            </label>
            <input
              type="text"
              value={newPost.url}
              onChange={(e) => setNewPost({ ...newPost, url: e.target.value })}
              placeholder={`Paste ${newPost.type === 'youtube' ? 'YouTube video' : 'Instagram post'} link here...`}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#ff6b6b] focus:ring-2 focus:ring-[#ff6b6b]/20 transition-all duration-300"
            />
            <p className="mt-1 text-xs text-gray-500 italic">
              {newPost.type === 'youtube' 
                ? 'Example: https://www.youtube.com/watch?v=...' 
                : 'Example: https://www.instagram.com/p/...'}
            </p>
          </div>

          {error && !showPasswordModal && <p className="text-red-500 text-sm text-center">{error}</p>}

          <button
            onClick={() => {
              if (isAuthenticated) {
                handleSubmit();
              } else {
                setShowPasswordModal(true);
              }
            }}
            disabled={!newPost.url}
            className="w-full py-3 rounded-full bg-gradient-to-r from-[#ff6b6b] to-[#ff8787] text-white hover:shadow-lg hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
          >
            <span>Post to News</span>
            <span>📣</span>
          </button>
        </div>
      </div>

      {/* Posts Grid */}
      <div>
        <h3 className="text-sm text-gray-600 mb-4">Latest News ({posts.length})</h3>
        {posts.length === 0 ? (
          <div className="text-center py-16 bg-white/60 backdrop-blur-sm rounded-3xl shadow-md border border-white/50">
            <div className="text-6xl mb-4">📰</div>
            <p className="text-gray-500">No news posts yet. Be the first to share!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {posts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 30, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -30, scale: 0.95 }}
                  transition={{ 
                    duration: 0.5, 
                    delay: index * 0.1,
                    ease: [0.25, 0.1, 0.25, 1]
                  }}
                  className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-xl overflow-hidden group relative transition-all duration-300"
                >
                  {/* Delete Button */}
                  {showDeleteConfirm === post.id ? (
                    <div className="absolute top-3 right-3 z-10 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-3 min-w-[200px]">
                      <p className="text-xs text-gray-700 mb-2 text-center">Are you sure you want to delete this post?</p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleDeleteConfirm(post.id)}
                          className="flex-1 px-3 py-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 text-xs transition-colors"
                        >
                          Yes
                        </button>
                        <button
                          onClick={() => {
                            setShowDeleteConfirm(null);
                            setDeleteError('');
                          }}
                          className="flex-1 px-3 py-1.5 bg-gray-300 text-gray-700 rounded-full hover:bg-gray-400 text-xs transition-colors"
                        >
                          No
                        </button>
                      </div>
                    </div>
                  ) : showDeletePassword === post.id ? (
                    <div className="absolute top-3 right-3 z-10 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-3 min-w-[220px]">
                      <p className="text-xs text-gray-700 mb-2 text-center">Enter password to delete</p>
                      {deleteError && <p className="text-xs text-red-500 mb-2 text-center">{deleteError}</p>}
                      <div className="flex gap-2 mb-2">
                        <input
                          type="password"
                          value={deletePassword}
                          onChange={(e) => setDeletePassword(e.target.value)}
                          placeholder="Password"
                          className="flex-1 px-3 py-1.5 rounded-full text-xs border-2 border-gray-200 bg-white focus:outline-none focus:border-[#ff6b6b] focus:ring-2 focus:ring-[#ff6b6b]/20"
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleDelete(post.id)}
                          disabled={!deletePassword}
                          className="flex-1 px-3 py-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 text-xs transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Delete
                        </button>
                        <button
                          onClick={() => {
                            setShowDeletePassword(null);
                            setDeletePassword('');
                            setDeleteError('');
                          }}
                          className="flex-1 px-3 py-1.5 bg-gray-300 text-gray-700 rounded-full hover:bg-gray-400 text-xs transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleDeleteClick(post.id)}
                      className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-red-400/80 hover:bg-red-500/80 text-white p-2 rounded-full"
                      title="Delete post"
                    >
                      🗑️
                    </button>
                  )}

                  {post.type === 'youtube' && getEmbedUrl(post.url, post.type) ? (
                    <div className="aspect-video bg-black">
                      <iframe
                        src={getEmbedUrl(post.url, post.type)!}
                        className="w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="YouTube video"
                      />
                    </div>
                  ) : post.type === 'youtube' ? (
                    <div className="aspect-video bg-gray-100 flex items-center justify-center">
                      <p className="text-gray-400 text-sm">Invalid YouTube URL</p>
                    </div>
                  ) : null}
                  
                  {post.type === 'instagram' && (
                    <div className="aspect-video bg-gradient-to-br from-[#f58529] via-[#dd2a7b] to-[#8134af] flex flex-col items-center justify-center gap-3 p-6">
                      <Instagram className="w-12 h-12 text-white" />
                      <p className="text-white text-sm text-center">Instagram Post</p>
                      <a
                        href={post.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-white/20 hover:bg-white/30 text-white px-6 py-2 rounded-full text-sm transition-colors backdrop-blur-sm"
                      >
                        View on Instagram →
                      </a>
                    </div>
                  )}

                  <div className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {post.type === 'youtube' ? (
                        <Youtube className="w-4 h-4 text-red-500" />
                      ) : (
                        <Instagram className="w-4 h-4 text-pink-500" />
                      )}
                      <span className="text-xs text-gray-500">
                        {post.type === 'youtube' ? 'YouTube' : 'Instagram'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400">
                      {new Date(post.timestamp).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Password Modal */}
      <AnimatePresence>
        {showPasswordModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowPasswordModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full"
            >
              <h3 className="text-gray-800 mb-6 text-center">Enter Password to Post</h3>
              <div className="space-y-4">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 rounded-full bg-gray-50 border-2 border-gray-200 focus:outline-none focus:border-[#ff6b6b] focus:ring-2 focus:ring-[#ff6b6b]/20 transition-all duration-300"
                />
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowPasswordModal(false);
                      setPassword('');
                      setError('');
                    }}
                    className="flex-1 px-6 py-3 rounded-full bg-gray-200 hover:bg-gray-300 hover:scale-105 transition-all duration-300"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmit}
                    className="flex-1 px-6 py-3 rounded-full bg-gradient-to-r from-[#ff6b6b] to-[#ff8787] text-white hover:shadow-lg hover:scale-105 transition-all duration-300"
                  >
                    Post
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
