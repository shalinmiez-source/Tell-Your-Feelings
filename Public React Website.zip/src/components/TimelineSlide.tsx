import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, X } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface TimelinePost {
  id: string;
  username: string;
  caption: string;
  songLink: string;
  photos: string[];
  reactions: { heart: number; hands: number; flower: number };
  timestamp: number;
}

export function TimelineSlide() {
  const [posts, setPosts] = useState<TimelinePost[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeletePassword, setShowDeletePassword] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [newPost, setNewPost] = useState({
    username: '',
    caption: '',
    songLink: '',
  });
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [error, setError] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if password is stored in session
    const storedPassword = sessionStorage.getItem('rilism_password');
    if (storedPassword === 'RILISMWEIGHTEEN2526') {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
    const interval = setInterval(fetchPosts, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/timeline`,
        {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        setPosts(Array.isArray(data) ? data : []);
      } else {
        console.error('Error fetching timeline posts - HTTP status:', response.status);
        const errorData = await response.text();
        console.error('Error details:', errorData);
      }
    } catch (err) {
      // Continue silently - the server might not be ready yet or there's a network issue
      // This is expected on first load before the server is fully initialized
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files).slice(0, 4);
      setSelectedFiles(files);
    }
  };

  const handleSubmit = async () => {
    try {
      const postPassword = isAuthenticated ? sessionStorage.getItem('rilism_password') : password;
      
      const formData = new FormData();
      formData.append('password', postPassword || '');
      formData.append('username', newPost.username);
      formData.append('caption', newPost.caption);
      formData.append('songLink', newPost.songLink);
      
      selectedFiles.forEach((file, index) => {
        formData.append(`photo${index}`, file);
      });

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/timeline`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: formData,
        }
      );

      if (response.ok) {
        const newPostData = await response.json();
        // Store password in session on successful post
        if (!isAuthenticated) {
          sessionStorage.setItem('rilism_password', password);
          setIsAuthenticated(true);
        }
        // Add new post immediately to the list
        setPosts(prev => [newPostData, ...prev]);
        setShowPasswordModal(false);
        setPassword('');
        setNewPost({ username: '', caption: '', songLink: '' });
        setSelectedFiles([]);
        setError('');
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to post');
      }
    } catch (err) {
      setError('Network error');
      console.error('Error creating post:', err);
    }
  };

  const handleReact = async (postId: string, reaction: 'heart' | 'hands' | 'flower') => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/timeline/${postId}/react`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ reaction }),
        }
      );

      if (response.ok) {
        fetchPosts();
      }
    } catch (err) {
      console.error('Error reacting to post:', err);
    }
  };

  const handleDeleteClick = (postId: string) => {
    // First confirmation
    setShowDeleteConfirm(postId);
    setDeleteError('');
  };

  const handleDeleteConfirm = (postId: string) => {
    // Second confirmation - show password input
    setShowDeleteConfirm(null);
    setShowDeletePassword(postId);
  };

  const handleDelete = async (postId: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-075ac925/timeline/${postId}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ password: deletePassword }),
        }
      );

      if (response.ok) {
        // Remove post immediately from the list
        setPosts(prev => prev.filter(p => p.id !== postId));
        setShowDeletePassword(null);
        setDeletePassword('');
        setDeleteError('');
      } else {
        const data = await response.json();
        setDeleteError(data.error || 'Failed to delete');
      }
    } catch (err) {
      setDeleteError('Network error');
      console.error('Error deleting post:', err);
    }
  };

  const getSongEmbedUrl = (url: string) => {
    if (url.includes('spotify.com')) {
      const trackId = url.match(/track\/([a-zA-Z0-9]+)/)?.[1];
      return trackId ? `https://open.spotify.com/embed/track/${trackId}?utm_source=generator&theme=0` : null;
    } else if (url.includes('youtube.com') || url.includes('youtu.be')) {
      const videoId = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/)?.[1];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
    }
    return null;
  };

  const filteredPosts = posts.filter((post) =>
    searchQuery.trim() === '' ||
    post.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-[#4ecdc4] mb-2">💚 Timeline 📸</h2>
        <p className="text-sm text-gray-600">Share your feelings through images and audio</p>
      </div>

      {/* Post Form */}
      <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg p-6 mb-6 border border-white/50">
        <h3 className="text-gray-800 text-center mb-6">Share Your Feelings</h3>
        
        <div className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={newPost.username}
              onChange={(e) => setNewPost({ ...newPost, username: e.target.value })}
              placeholder="Your name"
              maxLength={50}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20 transition-all duration-300"
            />
            <span className="absolute right-4 top-3 text-xs text-gray-400">{newPost.username.length}/50</span>
          </div>

          <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:border-[#4ecdc4] hover:bg-[#4ecdc4]/5 transition-all duration-300 shadow-sm hover:shadow-md">
            <label className="cursor-pointer">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2 transition-transform hover:scale-110" />
              <p className="text-gray-600 mb-1">Click to upload an image</p>
              <p className="text-xs text-gray-400">PNG, JPG, or up to 10MB</p>
              {selectedFiles.length > 0 && (
                <p className="text-sm text-[#4ecdc4] mt-2">{selectedFiles.length} photo(s) selected ✓</p>
              )}
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          </div>

          <div>
            <input
              type="text"
              value={newPost.songLink}
              onChange={(e) => setNewPost({ ...newPost, songLink: e.target.value })}
              placeholder="Add a Spotify or YouTube link (optional)"
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20 transition-all duration-300"
            />
            <p className="mt-1 text-xs text-gray-500 italic">Share your favorite track from Spotify or YouTube</p>
          </div>

          <div className="relative">
            <textarea
              value={newPost.caption}
              onChange={(e) => setNewPost({ ...newPost, caption: e.target.value })}
              placeholder="Write a caption for your post... (optional)"
              maxLength={500}
              rows={3}
              className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-gray-200 focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20 transition-all duration-300 resize-none"
            />
            <span className="absolute right-4 bottom-3 text-xs text-gray-400">{newPost.caption.length}/500</span>
          </div>

          <button
            onClick={() => {
              if (isAuthenticated) {
                handleSubmit();
              } else {
                setShowPasswordModal(true);
              }
            }}
            disabled={!newPost.username}
            className="w-full py-3 rounded-full bg-gradient-to-r from-[#7dd87d] to-[#4ecdc4] text-white hover:shadow-lg hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
          >
            <span>Share Your Feelings</span>
            <span>✨</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="🔍 Search by username..."
          className="w-full px-5 py-3 rounded-full bg-white/80 backdrop-blur-sm border-2 border-gray-200 focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20 transition-all duration-300 shadow-sm hover:shadow-md"
        />
      </div>

      {/* Posts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {filteredPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              transition={{ 
                duration: 0.4, 
                delay: index * 0.08,
                ease: [0.25, 0.1, 0.25, 1]
              }}
              className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-xl overflow-hidden group relative transition-all duration-300"
            >
              {/* Delete Button */}
              {showDeleteConfirm === post.id ? (
                <div className="absolute top-3 right-3 z-10 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-3 min-w-[200px]">
                  <p className="text-xs text-gray-700 mb-2 text-center">Are you sure you want to delete this post?</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDeleteConfirm(post.id)}
                      className="flex-1 px-3 py-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 text-xs transition-colors"
                    >
                      Yes
                    </button>
                    <button
                      onClick={() => {
                        setShowDeleteConfirm(null);
                        setDeleteError('');
                      }}
                      className="flex-1 px-3 py-1.5 bg-gray-300 text-gray-700 rounded-full hover:bg-gray-400 text-xs transition-colors"
                    >
                      No
                    </button>
                  </div>
                </div>
              ) : showDeletePassword === post.id ? (
                <div className="absolute top-3 right-3 z-10 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-3 min-w-[220px]">
                  <p className="text-xs text-gray-700 mb-2 text-center">Enter password to delete</p>
                  {deleteError && <p className="text-xs text-red-500 mb-2 text-center">{deleteError}</p>}
                  <div className="flex gap-2 mb-2">
                    <input
                      type="password"
                      value={deletePassword}
                      onChange={(e) => setDeletePassword(e.target.value)}
                      placeholder="Password"
                      className="flex-1 px-3 py-1.5 rounded-full text-xs border-2 border-gray-200 bg-white focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDelete(post.id)}
                      disabled={!deletePassword}
                      className="flex-1 px-3 py-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 text-xs transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Delete
                    </button>
                    <button
                      onClick={() => {
                        setShowDeletePassword(null);
                        setDeletePassword('');
                        setDeleteError('');
                      }}
                      className="flex-1 px-3 py-1.5 bg-gray-300 text-gray-700 rounded-full hover:bg-gray-400 text-xs transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => handleDeleteClick(post.id)}
                  className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-red-400/80 hover:bg-red-500/80 text-white p-2 rounded-full"
                  title="Delete post"
                >
                  🗑️
                </button>
              )}

              {/* Photos */}
              {post.photos && post.photos.length > 0 && (
                <div className={`grid ${post.photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2'} gap-2 p-3`}>
                  {post.photos.map((photo, idx) => (
                    <img
                      key={idx}
                      src={photo}
                      alt={`Photo ${idx + 1}`}
                      className={`w-full ${post.photos.length === 1 ? 'h-48' : 'h-32'} object-cover rounded-2xl transition-transform duration-300 hover:scale-105`}
                    />
                  ))}
                </div>
              )}

              <div className="p-4">
                <p className="text-sm text-gray-700 mb-2">@{post.username}</p>
                {post.caption && (
                  <p className="text-xs text-gray-600 mb-3">{post.caption}</p>
                )}

                {/* Song Embed */}
                {post.songLink && getSongEmbedUrl(post.songLink) && (
                  <div className="mb-3 rounded-2xl overflow-hidden">
                    <iframe
                      src={getSongEmbedUrl(post.songLink)!}
                      width="100%"
                      height="80"
                      frameBorder="0"
                      allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                      loading="lazy"
                    />
                  </div>
                )}

                {/* Reactions */}
                <div className="flex gap-3 mb-2">
                  <button
                    onClick={() => handleReact(post.id, 'heart')}
                    className="text-xs hover:scale-125 transition-all duration-200 px-2 py-1 rounded-full hover:bg-white/50"
                  >
                    🤍 {post.reactions.heart}
                  </button>
                  <button
                    onClick={() => handleReact(post.id, 'hands')}
                    className="text-xs hover:scale-125 transition-all duration-200 px-2 py-1 rounded-full hover:bg-white/50"
                  >
                    🫶🏻 {post.reactions.hands}
                  </button>
                  <button
                    onClick={() => handleReact(post.id, 'flower')}
                    className="text-xs hover:scale-125 transition-all duration-200 px-2 py-1 rounded-full hover:bg-white/50"
                  >
                    🌺 {post.reactions.flower}
                  </button>
                </div>

                <p className="text-xs text-gray-400">
                  {new Date(post.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Password Modal */}
      <AnimatePresence>
        {showPasswordModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowPasswordModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full"
            >
              <h3 className="text-gray-800 mb-6 text-center">Enter Password to Post</h3>
              <div className="space-y-4">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-3 rounded-full bg-gray-50 border-2 border-gray-200 focus:outline-none focus:border-[#4ecdc4] focus:ring-2 focus:ring-[#4ecdc4]/20 transition-all duration-300"
                />
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowPasswordModal(false);
                      setPassword('');
                      setError('');
                    }}
                    className="flex-1 px-6 py-3 rounded-full bg-gray-200 hover:bg-gray-300 hover:scale-105 transition-all duration-300"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmit}
                    className="flex-1 px-6 py-3 rounded-full bg-gradient-to-r from-[#7dd87d] to-[#4ecdc4] text-white hover:shadow-lg hover:scale-105 transition-all duration-300"
                  >
                    Post
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
