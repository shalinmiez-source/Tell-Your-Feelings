import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Password constants
const NEWS_PASSWORD = 'RILISMWEIGHTEEN2526';
const POST_PASSWORD = 'RILISMWEIGHTEEN2526';
const DELETE_PASSWORD = 'RILISMWEIGHTEEN2526';

// Initialize storage bucket
async function initStorage() {
  const bucketName = 'make-075ac925-rilism-photos';
  const { data: buckets } = await supabase.storage.listBuckets();
  const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
  if (!bucketExists) {
    await supabase.storage.createBucket(bucketName, { public: false });
  }
}

initStorage().catch(console.error);

// ========== NEWS ROUTES ==========

// Get all news posts
app.get('/make-server-075ac925/news', async (c) => {
  try {
    const posts = await kv.getByPrefix('news:');
    const sortedPosts = posts.sort((a, b) => b.timestamp - a.timestamp);
    return c.json(sortedPosts);
  } catch (error) {
    console.log(`Error fetching news posts: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Create news post
app.post('/make-server-075ac925/news', async (c) => {
  try {
    const { password, url, type } = await c.req.json();
    
    if (password !== NEWS_PASSWORD) {
      return c.json({ error: 'Invalid password' }, 401);
    }
    
    const post = {
      id: crypto.randomUUID(),
      url,
      type, // 'youtube' or 'instagram'
      timestamp: Date.now()
    };
    
    await kv.set(`news:${post.id}`, post);
    return c.json(post);
  } catch (error) {
    console.log(`Error creating news post: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Delete news post
app.delete('/make-server-075ac925/news/:id', async (c) => {
  try {
    const { password } = await c.req.json();
    const id = c.req.param('id');
    
    if (password !== DELETE_PASSWORD) {
      return c.json({ error: 'Invalid password' }, 401);
    }
    
    await kv.del(`news:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting news post: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// ========== TIMELINE ROUTES ==========

// Get all timeline posts
app.get('/make-server-075ac925/timeline', async (c) => {
  try {
    const posts = await kv.getByPrefix('timeline:');
    const sortedPosts = posts.sort((a, b) => b.timestamp - a.timestamp);
    
    // Get signed URLs for photos
    const postsWithUrls = await Promise.all(sortedPosts.map(async (post) => {
      if (post.photos && post.photos.length > 0) {
        const signedUrls = await Promise.all(post.photos.map(async (path: string) => {
          const { data } = await supabase.storage
            .from('make-075ac925-rilism-photos')
            .createSignedUrl(path, 3600);
          return data?.signedUrl || '';
        }));
        return { ...post, photos: signedUrls };
      }
      return post;
    }));
    
    return c.json(postsWithUrls);
  } catch (error) {
    console.log(`Error fetching timeline posts: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Create timeline post
app.post('/make-server-075ac925/timeline', async (c) => {
  try {
    const formData = await c.req.formData();
    const password = formData.get('password') as string;
    
    if (password !== POST_PASSWORD) {
      return c.json({ error: 'Invalid password' }, 401);
    }
    
    const username = formData.get('username') as string;
    const caption = formData.get('caption') as string;
    const songLink = formData.get('songLink') as string;
    
    const photoFiles: File[] = [];
    for (let i = 0; i < 4; i++) {
      const file = formData.get(`photo${i}`) as File;
      if (file) photoFiles.push(file);
    }
    
    // Upload photos
    const photoPaths: string[] = [];
    for (const file of photoFiles) {
      const filename = `timeline/${crypto.randomUUID()}-${file.name}`;
      const arrayBuffer = await file.arrayBuffer();
      const { error } = await supabase.storage
        .from('make-075ac925-rilism-photos')
        .upload(filename, new Uint8Array(arrayBuffer), {
          contentType: file.type
        });
      
      if (!error) photoPaths.push(filename);
    }
    
    const post = {
      id: crypto.randomUUID(),
      username,
      caption,
      songLink,
      photos: photoPaths,
      reactions: { heart: 0, hands: 0, flower: 0 },
      timestamp: Date.now()
    };
    
    await kv.set(`timeline:${post.id}`, post);
    
    // Get signed URLs for response
    const signedUrls = await Promise.all(photoPaths.map(async (path) => {
      const { data } = await supabase.storage
        .from('make-075ac925-rilism-photos')
        .createSignedUrl(path, 3600);
      return data?.signedUrl || '';
    }));
    
    return c.json({ ...post, photos: signedUrls });
  } catch (error) {
    console.log(`Error creating timeline post: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// React to timeline post
app.post('/make-server-075ac925/timeline/:id/react', async (c) => {
  try {
    const id = c.req.param('id');
    const { reaction } = await c.req.json();
    
    const post = await kv.get(`timeline:${id}`);
    if (!post) {
      return c.json({ error: 'Post not found' }, 404);
    }
    
    post.reactions[reaction] = (post.reactions[reaction] || 0) + 1;
    await kv.set(`timeline:${id}`, post);
    
    return c.json(post.reactions);
  } catch (error) {
    console.log(`Error reacting to timeline post: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Delete timeline post
app.delete('/make-server-075ac925/timeline/:id', async (c) => {
  try {
    const { password } = await c.req.json();
    const id = c.req.param('id');
    
    if (password !== DELETE_PASSWORD) {
      return c.json({ error: 'Invalid password' }, 401);
    }
    
    const post = await kv.get(`timeline:${id}`);
    if (post && post.photos) {
      // Delete photos from storage
      for (const path of post.photos) {
        await supabase.storage
          .from('make-075ac925-rilism-photos')
          .remove([path]);
      }
    }
    
    await kv.del(`timeline:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting timeline post: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// ========== MENFESS ROUTES ==========

// Get all menfess messages
app.get('/make-server-075ac925/menfess', async (c) => {
  try {
    const messages = await kv.getByPrefix('menfess:');
    const sortedMessages = messages.sort((a, b) => b.timestamp - a.timestamp);
    
    // Get signed URLs for photos
    const messagesWithUrls = await Promise.all(sortedMessages.map(async (msg) => {
      if (msg.photos && msg.photos.length > 0) {
        const signedUrls = await Promise.all(msg.photos.map(async (path: string) => {
          const { data } = await supabase.storage
            .from('make-075ac925-rilism-photos')
            .createSignedUrl(path, 3600);
          return data?.signedUrl || '';
        }));
        return { ...msg, photos: signedUrls };
      }
      return msg;
    }));
    
    return c.json(messagesWithUrls);
  } catch (error) {
    console.log(`Error fetching menfess messages: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Create menfess message
app.post('/make-server-075ac925/menfess', async (c) => {
  try {
    const formData = await c.req.formData();
    const from = formData.get('from') as string;
    const to = formData.get('to') as string;
    const message = formData.get('message') as string;
    const songLink = formData.get('songLink') as string;
    const color = formData.get('color') as string || 'pink';
    
    const photoFiles: File[] = [];
    for (let i = 0; i < 4; i++) {
      const file = formData.get(`photo${i}`) as File;
      if (file) photoFiles.push(file);
    }
    
    // Upload photos
    const photoPaths: string[] = [];
    for (const file of photoFiles) {
      const filename = `menfess/${crypto.randomUUID()}-${file.name}`;
      const arrayBuffer = await file.arrayBuffer();
      const { error } = await supabase.storage
        .from('make-075ac925-rilism-photos')
        .upload(filename, new Uint8Array(arrayBuffer), {
          contentType: file.type
        });
      
      if (!error) photoPaths.push(filename);
    }
    
    const msg = {
      id: crypto.randomUUID(),
      from,
      to,
      message,
      songLink,
      color,
      photos: photoPaths,
      timestamp: Date.now()
    };
    
    await kv.set(`menfess:${msg.id}`, msg);
    
    // Get signed URLs for response
    const signedUrls = await Promise.all(photoPaths.map(async (path) => {
      const { data } = await supabase.storage
        .from('make-075ac925-rilism-photos')
        .createSignedUrl(path, 3600);
      return data?.signedUrl || '';
    }));
    
    return c.json({ ...msg, photos: signedUrls });
  } catch (error) {
    console.log(`Error creating menfess message: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

// Delete menfess message (no password required)
app.delete('/make-server-075ac925/menfess/:id', async (c) => {
  try {
    const id = c.req.param('id');
    
    const msg = await kv.get(`menfess:${id}`);
    if (msg && msg.photos) {
      // Delete photos from storage
      for (const path of msg.photos) {
        await supabase.storage
          .from('make-075ac925-rilism-photos')
          .remove([path]);
      }
    }
    
    await kv.del(`menfess:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting menfess message: ${error}`);
    return c.json({ error: String(error) }, 500);
  }
});

Deno.serve(app.fetch);
